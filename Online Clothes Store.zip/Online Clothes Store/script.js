// hamsburger Button

// const bar = document.getElementById('bar')
// const nav = document.getElementById('navbar')
// const close = document.getElementById('close')

// if(bar) {
//     bar.addEventListener('click', () => {
//         nav.classList.add('active');
//     })
// }

// if(close) {
//     close.addEventListener('click', () => {
//         nav.classList.remove('active');
//     })
// }

// var MenuItems = document.getElementsByClassName("MenuItems");

// MenuItems.style.maxHeight = "0px";

// function MenuToggle() {
//     if (MenuItems.style.maxHeight == "0px") {
//         MenuItems.style.maxHeight = "200px";
//     }
//     else {
//         MenuItems.style.maxHeight = "0px";
//     }
// }

// Single Product Slider

var MainImage = document.getElementById("MainImage");
var smallimg = document.getElementsByClassName("small-img");

smallimg[0].onclick = function (){
    MainImage.src = smallimg[0].src
}
smallimg[1].onclick = function (){
    MainImage.src = smallimg[1].src
}
smallimg[2].onclick = function (){
    MainImage.src = smallimg[2].src
}
smallimg[3].onclick = function (){
    MainImage.src = smallimg[3].src
}